package com.headcam;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Settings live in config/bbs_head_camera.json. Edit the file and restart (or re-enter the world).
 */
public class HeadCameraConfig
{
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HeadCameraConfig instance = new HeadCameraConfig();

    /** Master switch. */
    public boolean enabled = true;
    /** Bone the camera follows. Matched by name, case-insensitive (also matches nested paths ending in /name). */
    public String bone = "head";
    /** Camera copies the head bone's rotation. */
    public boolean followRotation = true;
    /** Camera moves with the head bone's position. If it feels off, set to false to keep the normal eye position. */
    public boolean followPosition = true;
    /** Distance (in blocks) from the head bone pivot up to the eyes. */
    public float eyeOffset = 0.25F;
    /**
     * Only turn this on if your model's head bone does NOT already follow the actor's head yaw/pitch.
     * Adds the entity head yaw/pitch (relative to the body) on top of the bone rotation.
     */
    public boolean addEntityLook = false;
    /** Logs the available bone names once if the bone can't be found. */
    public boolean logMissingBone = true;

    public static HeadCameraConfig get()
    {
        return instance;
    }

    public static void load()
    {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("bbs_head_camera.json");

        try
        {
            if (Files.exists(path))
            {
                try (Reader reader = Files.newBufferedReader(path))
                {
                    HeadCameraConfig loaded = GSON.fromJson(reader, HeadCameraConfig.class);

                    if (loaded != null)
                    {
                        instance = loaded;
                    }
                }
            }

            try (Writer writer = Files.newBufferedWriter(path))
            {
                GSON.toJson(instance, writer);
            }
        }
        catch (Exception e)
        {
            HeadCameraFollow.LOGGER.warn("Could not read/write bbs_head_camera.json, using defaults", e);
        }
    }
}
