package com.headcam.mixin;

import com.headcam.HeadCameraFollow;
import mchorse.bbs_mod.camera.Camera;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.ui.film.controller.ActorCamera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * BBS places the first-person camera at the entity's eye position using the entity head yaw/pitch.
 * After it does that, we re-aim/re-position the camera using the head bone of the actor's form,
 * so edited head poses are visible in first person.
 */
@Mixin(value = ActorCamera.class, remap = false)
public class ActorCameraMixin
{
    @Inject(method = "firstPerson", at = @At("TAIL"), remap = false)
    private static void bbshc$followHead(Camera camera, IEntity entity, float transition, CallbackInfo ci)
    {
        HeadCameraFollow.apply(camera, entity, transition);
    }
}
