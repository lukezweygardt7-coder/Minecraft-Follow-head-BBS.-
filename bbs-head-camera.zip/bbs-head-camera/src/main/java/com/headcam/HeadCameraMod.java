package com.headcam;

import net.fabricmc.api.ClientModInitializer;

public class HeadCameraMod implements ClientModInitializer
{
    @Override
    public void onInitializeClient()
    {
        HeadCameraConfig.load();
        HeadCameraFollow.LOGGER.info("BBS Head Camera loaded (config: config/bbs_head_camera.json)");
    }
}
