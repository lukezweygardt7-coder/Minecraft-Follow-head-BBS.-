package com.headcam;

import mchorse.bbs_mod.camera.Camera;
import mchorse.bbs_mod.film.FilmMatrices;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.renderers.utils.FormFrameCache;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCacheEntry;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HeadCameraFollow
{
    public static final Logger LOGGER = LoggerFactory.getLogger("bbshc");

    private static boolean warnedMissing;
    private static boolean warnedError;

    /** Called after BBS has set the normal first-person camera. */
    public static void apply(Camera camera, IEntity entity, float transition)
    {
        HeadCameraConfig config = HeadCameraConfig.get();

        if (!config.enabled || entity == null || entity.getForm() == null)
        {
            return;
        }

        try
        {
            follow(config, camera, entity, transition);
        }
        catch (Throwable t)
        {
            if (!warnedError)
            {
                warnedError = true;
                LOGGER.warn("Head camera failed, falling back to the normal first person camera", t);
            }
        }
    }

    private static void follow(HeadCameraConfig config, Camera camera, IEntity entity, float t)
    {
        Form root = FormUtils.getRoot(entity.getForm());
        MatrixCache cache = new FormFrameCache().collect(root, entity, t);
        MatrixCacheEntry entry = find(cache, config.bone);

        if (entry == null || entry.matrix() == null)
        {
            if (config.logMissingBone && !warnedMissing)
            {
                warnedMissing = true;

                List<String> keys = new ArrayList<>();

                for (Map.Entry<String, MatrixCacheEntry> e : cache.entrySet())
                {
                    keys.add(e.getKey());
                }

                LOGGER.warn("Head bone '{}' not found. Available bones: {}", config.bone, keys);
            }

            return;
        }

        double ex = lerp(entity.getPrevX(), entity.getX(), t);
        double ey = lerp(entity.getPrevY(), entity.getY(), t);
        double ez = lerp(entity.getPrevZ(), entity.getZ(), t);

        /* Passing the entity's own position as origin gives a pure body-yaw rotation matrix. */
        Matrix4f world = new Matrix4f(FilmMatrices.getMatrixForRenderWithRotation(entity, ex, ey, ez, t));

        world.mul(entry.matrix());

        Vector3f pivot = world.transformPosition(new Vector3f());
        Vector3f forward = world.transformDirection(new Vector3f(0, 0, 1)).normalize();
        Vector3f up = world.transformDirection(new Vector3f(0, 1, 0)).normalize();

        float originalYaw = (float) (camera.rotation.y - Math.PI);

        /* The model's local axes can be flipped depending on the model format, so pick the signs that
         * agree with the camera BBS just computed from the entity (yaw closest / eyes closest). */
        if (angleDiff(yawOf(forward), originalYaw) > angleDiff(yawOf(new Vector3f(forward).negate()), originalYaw))
        {
            forward.negate();
        }

        if (config.followPosition)
        {
            double ox = camera.position.x;
            double oy = camera.position.y;
            double oz = camera.position.z;

            double ax = ex + pivot.x + up.x * config.eyeOffset;
            double ay = ey + pivot.y + up.y * config.eyeOffset;
            double az = ez + pivot.z + up.z * config.eyeOffset;
            double bx = ex + pivot.x - up.x * config.eyeOffset;
            double by = ey + pivot.y - up.y * config.eyeOffset;
            double bz = ez + pivot.z - up.z * config.eyeOffset;

            double da = sq(ax - ox) + sq(ay - oy) + sq(az - oz);
            double db = sq(bx - ox) + sq(by - oy) + sq(bz - oz);

            if (da <= db)
            {
                camera.position.set(ax, ay, az);
            }
            else
            {
                camera.position.set(bx, by, bz);
            }
        }

        if (config.followRotation)
        {
            float yaw = yawOf(forward);
            float pitch = (float) Math.asin(Math.max(-1F, Math.min(1F, -forward.y)));

            if (config.addEntityLook)
            {
                float headYaw = (float) Math.toRadians(lerp(entity.getPrevHeadYaw(), entity.getHeadYaw(), t));
                float bodyYaw = (float) Math.toRadians(lerp(entity.getPrevBodyYaw(), entity.getBodyYaw(), t));

                yaw += headYaw - bodyYaw;
                pitch += (float) Math.toRadians(lerp(entity.getPrevPitch(), entity.getPitch(), t));
            }

            /* Same convention BBS uses in ActorCamera.firstPerson: (pitch, yaw + PI, roll). */
            camera.rotation.set(pitch, (float) (yaw + Math.PI), 0F);
        }
    }

    private static MatrixCacheEntry find(MatrixCache cache, String bone)
    {
        if (bone == null || bone.isEmpty())
        {
            return null;
        }

        String lower = bone.toLowerCase();
        MatrixCacheEntry suffix = null;

        for (Map.Entry<String, MatrixCacheEntry> e : cache.entrySet())
        {
            String key = e.getKey().toLowerCase();

            if (key.equals(lower))
            {
                return e.getValue();
            }

            if (suffix == null && key.endsWith("/" + lower))
            {
                suffix = e.getValue();
            }
        }

        return suffix;
    }

    /** Minecraft convention: yaw 0 looks toward +Z, direction = (-sin yaw, ., cos yaw). */
    private static float yawOf(Vector3f direction)
    {
        return (float) Math.atan2(-direction.x, direction.z);
    }

    private static float angleDiff(float a, float b)
    {
        double d = (a - b) % (Math.PI * 2);

        if (d > Math.PI) d -= Math.PI * 2;
        if (d < -Math.PI) d += Math.PI * 2;

        return (float) Math.abs(d);
    }

    private static double lerp(double a, double b, double t)
    {
        return a + (b - a) * t;
    }

    private static float lerp(float a, float b, float t)
    {
        return a + (b - a) * t;
    }

    private static double sq(double v)
    {
        return v * v;
    }
}
